#  python3 command_HTcondor.py
submitFileTT="""
universe = vanilla
executable            = command_HTcondor.sh
transfer_output_files   = ""
+JobFlavour            = "tomorrow"
Transfer_Input_Files  = files.tar.gz
#Request_Disk = 1024
#Request_Memory = 1024
#Request_cpus = 1
#Requirements = OpSys == "LINUX" && (Arch != "DUMMY" )
Should_Transfer_Files = YES
x509userproxy = $ENV(X509_USER_PROXY)
"""
import os
import sys
from os import system, environ

# usage: python3 command_HTcondor.py year preVFP isData doEB
if len(sys.argv) != 5:
    sys.exit("usage: python3 command_HTcondor.py year preVFP isData doEB")
year, preVFP, isData, doEB = [int(a) for a in sys.argv[1:5]]
tag = "{}_{}_{}_{}".format(year, preVFP, isData, doEB)

files = open("RunnerScript.txt","r") 
count = 0
system("mkdir -p logs condorSubFile")
for ij in files:
    cols = ij.strip().split(' ')
    fileParts = [submitFileTT]
    count += 1
    if len(cols) >= 9:
        # useCrossBinning line: 7 default args + crossbinlow + crossbinhigh
        fileParts.append("Arguments = {} {} {} {} {} {} {} {} {} {} {} {} {}\n".format(
            year, preVFP, isData, doEB,
            int(cols[0]), int(cols[1]), int(cols[2]), float(cols[3]), float(cols[4]),
            int(cols[5]), int(cols[6]), float(cols[7]), float(cols[8])))
    else:
        # default 7-argument line (useCrossBinning off)
        fileParts.append("Arguments = {} {} {} {} {} {} {} {} {} {} {}\n".format(
            year, preVFP, isData, doEB,
            int(cols[0]), int(cols[1]), int(cols[2]), float(cols[3]), float(cols[4]),
            int(cols[5]), int(cols[6])))
    fileParts.append("Queue \n \n")
    fout = open("condorSubFile/condor_sub_{}_{}.txt".format(tag, count),"w")
    fout.write(''.join(fileParts))
    fout.close()
    fileParts.pop(-1)
    fileParts.pop(-1)
    system('condor_submit condorSubFile/condor_sub_{}_{}.txt'.format(tag, count))
    del fileParts
files.close()
